﻿using System;

namespace MonAssoce.Data.Models
{
    public class OfficeMember : Member
    {

        public string Title { get; set; }

    }
}
